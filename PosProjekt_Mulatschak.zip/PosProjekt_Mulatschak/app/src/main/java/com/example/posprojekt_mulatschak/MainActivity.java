package com.example.posprojekt_mulatschak;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    DatabaseReference mDatabase;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    Socket socket;
    ArrayList<Integer> images = new ArrayList<>();
    ArrayList<Integer> cardsForDeal = new ArrayList<>();
    boolean card1;
    boolean card2;
    boolean card3;
    boolean card4;
    boolean card5;
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.start);
        //try {
        //    socket = new Socket("localhost", 255555);
        //} catch (IOException e) {
        //    e.printStackTrace();
        //}
        mDatabase = FirebaseDatabase.getInstance().getReference("cards");
        EditText player1 = findViewById(R.id.player1_pt);
        String player1Name = player1.getText().toString();

        //ImageView reartest = findViewById(R.id.imageView);
        // reartest.setImageBitmap(deck.getPicture(0));
        //ImageView testCards = findViewById(R.id.testCard);
        //int[] images = {R.drawable.herz8,R.drawable.herz9,R.drawable.herz10,R.drawable.herzkoenig};
        //Random rand = new Random();

        //testCards.setImageResource(R.drawable.eichel6);


    }

    public static void shuffle() {

    }

    public void onStartClick(View view) {
       // try {

       //     InputStream inputStream = socket.getInputStream();
       //     InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
       //     BufferedReader br = new BufferedReader(inputStreamReader);
       //     while (true) {
       //         if (Integer.parseInt(br.readLine()) < 2) {
       //             break;
       //         }
       //     }
       // } catch (IOException e) {
       //     e.printStackTrace();


        //String name = findViewById(R.id.player1_pt).toString();
        //mDatabase.child("user").child("1").setValue(null);
        //DatabaseReference myRef = database.getReference("message");
        //myRef.setValue("Hello World");
        DatabaseReference myRef = database.getReference("name");
        myRef.setValue(findViewById(R.id.player1_pt).toString());
        setContentView(R.layout.hands);

        fillCards();
        DatabaseReference card1 = database.getInstance().getReference("card1");
        card1.child("card1").setValue((Object) findViewById(R.id.imageView).toString());
        DatabaseReference card2 = database.getInstance().getReference("card2");
        card2.child("card2").setValue((Object) findViewById(R.id.imageView2).toString());
        DatabaseReference card3 = database.getInstance().getReference("card3");
        card3.child("card3").setValue((Object) findViewById(R.id.imageView3).toString());
        DatabaseReference card4 = database.getInstance().getReference("card4");
        card4.child("card4").setValue((Object) findViewById(R.id.imageView4).toString());
        DatabaseReference card5 = database.getInstance().getReference("card5");
        card5.child("card5").setValue((Object) findViewById(R.id.imageView5).toString());
        //card1.setValue(findViewById(R.id.imageView).toString());
    }

    public void fillCards() {
        int[] pics = {R.drawable.eichelacht, R.drawable.eichelkoenig, R.drawable.eichelneun, R.drawable.eichelober, R.drawable.eichelsau, R.drawable.eichelsechs, R.drawable.eichelsieben, R.drawable.eichelunter, R.drawable.eichelzehn,
                R.drawable.herzacht, R.drawable.herzkoenig, R.drawable.herzneun, R.drawable.herzober, R.drawable.herzsau, R.drawable.herzsieben, R.drawable.herzunter, R.drawable.herzzehn,
                R.drawable.laubacht, R.drawable.laubkoenig, R.drawable.laubneun, R.drawable.laubober, R.drawable.laubsau, R.drawable.laubsechs, R.drawable.laubsieben, R.drawable.laubunter, R.drawable.laubzehn,
                R.drawable.schellenacht, R.drawable.schellenkoenig, R.drawable.schellenneun, R.drawable.schellenober, R.drawable.schellensau, R.drawable.schellensechs, R.drawable.schellensieben, R.drawable.schellenunter, R.drawable.schellenzehn};
        ImageView image = findViewById(R.id.imageView);
        ImageView image2 = findViewById(R.id.imageView2);
        ImageView image3 = findViewById(R.id.imageView3);
        ImageView image4 = findViewById(R.id.imageView4);
        ImageView image5 = findViewById(R.id.imageView5);


        Random r = new Random();
        int i = r.nextInt(pics.length);
        image.setImageResource(pics[i]);
        images.add(pics[i]);
        i = r.nextInt(pics.length);
        image2.setImageResource(pics[i]);
        images.add(pics[i]);
        i = r.nextInt(pics.length);
        image3.setImageResource(pics[i]);
        images.add(pics[i]);
        i = r.nextInt(pics.length);
        image4.setImageResource(pics[i]);
        images.add(pics[i]);
        i = r.nextInt(pics.length);
        image5.setImageResource(pics[i]);
        images.add(pics[i]);


    }

    public void onStichansageClick(View view) {
        final DatabaseReference Ref = database.getReference("card 1");

        //image.setImageResource((Integer.valueOf(String.valueOf(database.getReference("card 1")))));
        setContentView(R.layout.stichansage);
        Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                //String data = snapshot.getValue(String.class);
                //ImageView image = (ImageView) findViewById(R.id.imageView8);
                //image.setImageResource(Integer.valueOf(data));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void onTrumpffarbeClick (View view) {
        //if (!findViewById(R.id.stiche_tv).toString().equals("")) {
        //    setContentView(R.layout.trumpffarbe);
        //    try {
        //        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        //    } catch (IOException e) {
        //        e.printStackTrace();
        setContentView(R.layout.trumpffarbe);
    }

    public void onEichelClick (View view) {
        mitgehen();
    }

    public void onSchellenClick (View view) {
        mitgehen();
    }

    public void onLaubClick (View view) {
        mitgehen();
    }

    public void everyone (View view) {
        kartentausch(view);
    }

    public void mitgehen () {
        setContentView(R.layout.mitgehen);
    }

    public void yesMitgehenClick (View view) {
        kartentausch(view);
    }

    public void kartentausch (View view) {
        setContentView(R.layout.kartentausch);
        setCardValues();
        showCardsForKartentausch();
    }

    public void showCardsForKartentausch () {
        ImageView image6 = findViewById(R.id.imageView6);
        ImageView image7 = findViewById(R.id.imageView7);
        ImageView image8 = findViewById(R.id.imageView8);
        ImageView image9 = findViewById(R.id.imageView9);
        ImageView image10 = findViewById(R.id.imageView10);
        image6.setImageResource(images.get(0));
        image7.setImageResource(images.get(1));
        image8.setImageResource(images.get(2));
        image9.setImageResource(images.get(3));
        image10.setImageResource(images.get(4));

    }

    public void noMitgehenClick (View view) {
        //pause
    }

    public void dealCards () {

       // if (card1) {
       //     ImageView image6 = findViewById(R.id.imageView6);
       //     image6.setImageResource(R.drawable.googleg_standard_color_18);
       // }
       // if (card2) {
       //     ImageView image7 = findViewById(R.id.imageView7);
       //     image7.setImageResource(cardsForDeal.get(0));
       // }
        //if (card3) {
       //     ImageView image8 = findViewById(R.id.imageView8);
       //     image8.setImageResource(cardsForDeal.get(0));
       // }
       // if (card4) {
        //    ImageView image9 = findViewById(R.id.imageView9);
         //   image9.setImageResource(cardsForDeal.get(0));
        //}
        //if (card5) {
        //    ImageView image10 = findViewById(R.id.imageView10);
        //    image10.setImageResource(cardsForDeal.get(0));
        }


    public void card1Click (View view) {
        cardsForDeal.add(images.get(0));
        card1 = true;
        Collections.shuffle(cardsForDeal);
    }

    public void card2Click (View view) {
        cardsForDeal.add(images.get(1));
        card2 = true;
        Collections.shuffle(cardsForDeal);
    }

    public void card3Click (View view) {
        cardsForDeal.add(images.get(2));
        card3 = true;
        Collections.shuffle(cardsForDeal);
    }

    public void card4Click (View view) {
        cardsForDeal.add(images.get(3));
        card4 = true;
        Collections.shuffle(cardsForDeal);
    }

    public void card5Click (View view) {
        cardsForDeal.add(images.get(4));
        card5 = true;
        Collections.shuffle(cardsForDeal);
        ImageView image6 = findViewById(R.id.imageView6);
        image6.setImageResource(cardsForDeal.get(0));
    }

    public void setCardValues () {
        card1 = false;
        card2 = false;
        card3 = false;
        card4 = false;
        card5 = false;
    }

            //TODO Buttons
            //send with "bw.write(toSend);
}

