package com.example.posprojekt_mulatschak;

import android.graphics.Bitmap;
import android.media.Image;

public class Card {
    //0-Eichel
    //1-Laub
    //2-Herz
    //3-Schellen

    private String faceName;
    private int faceValue, suit;
    private Bitmap cadImage;

    public Card(String faceName, int suit, int faceValue, Bitmap cadImage) {
        setCadImage(cadImage);
        setFaceName(faceName);
        setFaceValue(faceValue);
        setSuit(suit);
    }

    public String getFaceName() {
        return faceName;
    }

    public void setFaceName(String faceName) {
        this.faceName = faceName;
    }

    public int getSuit() {
        return suit;
    }

    public void setSuit(int suit) {
        this.suit = suit;
    }

    public int getFaceValue() {
        return faceValue;
    }

    public void setFaceValue(int faceValue) {
        this.faceValue = faceValue;
    }

    public Bitmap getCadImage() {
        return cadImage;
    }

    public void setCadImage(Bitmap cadImage) {
        this.cadImage = cadImage;
    }
}
